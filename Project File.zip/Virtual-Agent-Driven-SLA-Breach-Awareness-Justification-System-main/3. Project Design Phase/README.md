# Phase 3: Project Design Phase

This document outlines the detailed system architecture, data schema, workflow logic, conversational dialog trees, and user interface policies for the ServiceNow-native implementation of the SLA Breach Awareness & Justification System.

---

## 1. System Architecture Design

The solution is built entirely on native ServiceNow capabilities, ensuring compatibility with standard platform upgrades. The diagram below illustrates how components interact:

```mermaid
graph TD
    subgraph ServiceNow Platform
        Inc[Incident Table] <--> TSla[Task SLA Engine]
        Flow[Flow Designer] -.->|Triggers on 80% SLA| VA[Virtual Agent Designer]
        VA -.->|Conversational Dialog| Resolver[IT Support Agent]
        VA -.->|Update Record| Inc
        UIPol[UI Policies] -.->|Mandate Fields if Breached| Inc
        ACL[Access Control Lists] -.->|Restrict Editing| Inc
        Dash[Executive Analytics Hub] <--> Inc
    end
```

### Components Summary:
1. **SLA Engine (`task_sla`)**: Tracks percentage progression and flags breaches.
2. **Flow Designer**: Evaluates triggers and invokes the Virtual Agent context asynchronously.
3. **Virtual Agent Designer**: Governs conversational dialogue loops to collect audit comments.
4. **UI Policies & Data Policies**: Enforce data completeness on forms when viewed via the ServiceNow UI.
5. **Access Control Lists (ACLs)**: Secure submitted justifications to maintain audit integrity.
6. **Reporting Engine**: Populates dashboard widgets.

---

## 2. Schema Design (Data Model)

To capture SLA justifications and audit trails, we extend the standard Incident (`incident`) and Task SLA (`task_sla`) schemas.

```mermaid
erDiagram
    INCIDENT ||--o{ TASK_SLA : "monitored by"
    INCIDENT {
        string number PK
        string short_description
        string state
        string priority
        string assignee FK "sys_user"
        boolean u_requires_justification
        choice u_justification_reason "Dropdown list"
        string u_justification_comment "Audit detail"
        choice u_justification_status "Pending/Approved/Rejected"
        string u_manager_comments
    }
    TASK_SLA {
        string sys_id PK
        string task FK "incident"
        string sla FK "contract_sla"
        double percentage "Elapsed %"
        string stage "In Progress / Breached"
    }
```

### Custom Field Dictionary (Incident Table Extension)

| Field Name | Label | Data Type | Default / Choices | Description |
| :--- | :--- | :--- | :--- | :--- |
| `u_requires_justification` | Requires Justification | True/False | `False` | Triggered by Flow Designer when SLA crosses warning threshold. |
| `u_justification_reason` | Delay Reason Category | Choice List | See list below | Predefined categories to simplify agent entry. |
| `u_justification_comment` | Resolver Justification | Text (String) | None (Max 400 chars) | Custom explanation provided by the resolver. |
| `u_justification_status` | Justification Status | Choice List | `Pending Approval`<br>`Approved`<br>`Rejected` | Current audit state, updated by manager. |
| `u_manager_comments` | Manager Audit Notes | Text (String) | None | Comments added by the supervisor during reviews. |

#### `u_justification_reason` Choice Definitions:
1. `awaiting_customer`: Awaiting Customer Response
2. `vendor_delay`: Third-Party Vendor Delay
3. `technical_complexity`: High Technical Complexity / Research Required
4. `resource_shortage`: Resource / Staff Shortage
5. `hardware_delay`: Hardware Procurement / Provisioning Delay

---

## 3. Flow Designer Logic

A ServiceNow Flow handles notification dispatches and flag settings when the SLA engine detects threshold changes.

### Flow Definition: "SLA Warning & Agent Nudge"
* **Trigger Conditions**:
  * Record Table: Task SLA (`task_sla`)
  * Run: Once per record
  * Condition: `stage` changes to `In_Progress` AND `percentage` $\ge 80\%$ AND `task.sys_class_name` IS `Incident`.
* **Action Workflow Steps**:

```mermaid
stateDiagram-v2
    [*] --> Triggered
    Triggered --> Step1: Check Assignee exists
    Step1 --> Step2: Update Incident Record
    Note right of Step2: Set u_requires_justification = True
    Step2 --> Step3: Call Virtual Agent Action
    Note right of Step3: Pass Incident ID and Assignee User ID
    Step3 --> Step4: Send Notification Alerts
    Note right of Step4: Push notifications to Slack/Email
    Step4 --> [*]
```

---

## 4. Virtual Agent dialogue Design

The custom Virtual Agent Topic is designed using a branching decision tree inside the ServiceNow Virtual Agent Designer:

```mermaid
graph TD
    Start[Agent opens chat / VA pushes alert] --> Greet[Greet User & Display Incident details]
    Greet --> PromptReason[Show Dropdown: Select Delay Reason]
    PromptReason --> GetReason[Capture Choice Input]
    GetReason --> PromptComment[Prompt Text: Input details/explanation]
    PromptComment --> GetComment[Capture Text Input]
    GetComment --> DBWrite[Write justification data back to Incident record]
    DBWrite --> LogNote[System posts Work Note to Incident Activity Stream]
    LogNote --> PromptAction[Ask: Choose Post-Justification Action]
    PromptAction -->|Move On-Hold| HoldAction[Update State to On Hold & Pause SLA]
    PromptAction -->|Escalate Tier| EscalateAction[Post Escalate note & Alert manager]
    PromptAction -->|None| EndChat[End session with greeting]
    HoldAction --> EndChat
    EscalateAction --> EndChat
```

---

## 5. UI Policies & Client Security

### UI Policy: "Enforce Justification on Incident Forms"
* **Table**: Incident (`incident`)
* **Conditions**: `u_requires_justification` IS `True` AND `state` IS `Resolved` OR `state` IS `Closed`.
* **Actions (Zero-Code Rules)**:
  * Set `u_justification_reason` to **Visible = True** and **Mandatory = True**.
  * Set `u_justification_comment` to **Visible = True** and **Mandatory = True**.
  * Set `u_justification_status` to **Visible = True** and **Read-Only = True** (for Resolvers).

### Access Control Lists (ACLs) Rules
To maintain audit compliance, resolvers are blocked from editing fields once a justification is logged:

1. **Rule**: `incident.u_justification_reason` (Write)
   * **Role**: `itil`
   * **Condition**: `u_justification_status` IS `Pending Approval` AND `assigned_to` IS `javascript:gs.getUserID()`.
2. **Rule**: `incident.u_justification_status` (Write)
   * **Role**: `manager` or `sla_governor`
   * **Condition**: None (Managers always audit and change status).
3. **Rule**: `incident.u_justification_reason` & `incident.u_justification_comment` (Write)
   * **Role**: `itil`
   * **Condition**: `u_justification_status` IS `Approved` OR `u_justification_status` IS `Rejected`.
   * **Action**: **Deny Write** (locks the fields to create an immutable log once approved).

---

## 6. Executive Dashboard Design

The dashboard is structured into three logical zones to provide operational transparency:

| Row | Widget Type | Data Source | Visualization | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| **Row 1** | Single Score | `task_sla` | Big Number (e.g., $96.2\%$) | Real-time SLA compliance rate. |
| | Single Score | `incident` | Big Number | Count of active warning/breached tickets lacking justification. |
| **Row 2** | Bar Chart | `incident` | Vertical Bars | Breakdown of delay reasons (e.g., Awaiting Customer vs Vendor). |
| | Line Chart | `task_sla` | Trend Line | SLA compliance trends monitored week-over-week. |
| **Row 3** | List View | `incident` | Pivot Table | Pending approvals queue for managers to review and action. |
