# Phase-1: Brainstorming & Ideation

This document contains a comprehensive analysis, empathy mapping, and design ideation for implementing a proactive SLA governance solution within ServiceNow.

---

## 1. Problem Statement

In modern enterprise IT Service Management (ITSM), Service Level Agreements (SLAs) are critical for ensuring timely service delivery. However, organizations face significant challenges in managing SLA compliance effectively:

```mermaid
graph TD
    A[Passive SLA Monitoring] -->|No warnings| B[Unnoticed Near-Breaches]
    B -->|SLA Expires| C[Silent SLA Breaches]
    C -->|No Accountability| D[Lack of Justification & Audit Trail]
    D -->|Fines / SLA Penalties| E[Business Loss & Customer Dissatisfaction]
```

### The Core Challenges:
* **Passive Notification Fatigue**: Standard email alerts are often ignored or lost in agents' flooded inboxes, leading to "silent breaches" where tickets breach without the agent being actively aware.
* **Lack of Accountability**: When a breach occurs, there is no structured, mandatory mechanism to capture *why* it happened (e.g., waiting for vendor vs. lack of staff). Post-incident documentation is sparse, inconsistent, and difficult to audit.
* **Audit and Compliance Readiness**: Compliance teams struggle to trace the lifecycle of breached SLAs. Resolving disputes with clients or vendors is difficult without a clear audit trail of justifications and approvals.
* **Complex Customizations**: Traditional SLA enforcement in ServiceNow often relies on complex custom JavaScript (Client Scripts, Business Rules), which increases technical debt, degrades performance, and breaks during ServiceNow platform upgrades.

### The Solution:
An **admin-driven, zero-code SLA governance system** in ServiceNow that:
1. Proactively detects SLA risks.
2. Prompts agents through a **conversational Virtual Agent** to acknowledge risks and document justifications.
3. Restricts unauthorized edits via **Role-Based Access Controls (RBAC)**.
4. Generates an **Executive Dashboard** and audit logs for continuous performance improvement and compliance auditing.

---

## 2. Empathy Maps

To design a system that truly solves users' problems, we must understand the primary stakeholders.

### Persona 1: The IT Support Agent (The Frontline Resolver)
*Under constant pressure to resolve tickets, balancing volume and speed.*

| Category | Details |
| :--- | :--- |
| **SAYS** | *"I'm drowning in tickets; I don't have time to fill out extra paperwork just because an SLA is close."*<br>*"I didn't even notice this ticket was about to breach."* |
| **THINKS** | *I hope I don't get in trouble for this breach. It wasn't my fault anyway—the customer took three days to reply.*<br>*Why can't the system just tell me what to focus on next?* |
| **DOES** | Focuses on resolving tickets. Ignores standard email alerts. Scrambles to write quick, generic comments when a manager complains about a breach. |
| **FEELS** | Stressed by SLA timers, overwhelmed by notifications, and defensive when questioned about breaches. |
| **PAINS** | • Lack of clear, real-time prioritization.<br>• Punitive cultures around breaches instead of constructive tracking.<br>• Tedious form-filling to justify unavoidable delays. |
| **GAINS** | • Direct, conversational guidance from a virtual agent on what needs attention.<br>• Simplified, dropdown-based justification submissions.<br>• Clear recognition when a delay is outside their control (e.g., waiting on third party). |

---

### Persona 2: The IT Service Desk Manager (The Governor)
*Responsible for team compliance, client reporting, and resource planning.*

| Category | Details |
| :--- | :--- |
| **SAYS** | *"We need to show our clients that we respect our SLAs, and when we breach, we need to know exactly why."*<br>*"I spend too much time chasing agents for breach explanations before audit meetings."* |
| **THINKS** | *Are my teams understaffed, or are they just prioritizing the wrong tickets?*<br>*I need clear charts to present to the executive leadership team next week.* |
| **DOES** | Runs manual weekly reports to track breached tickets. Email-blasts agents for updates. Manually copies and pastes breach reasons into spreadsheets. |
| **FEELS** | Frustrated by the lack of structured data, anxious about upcoming client SLA reviews, and bogged down by manual administration. |
| **PAINS** | • "Empty" or useless breach comments (e.g., "breached").<br>• No real-time visibility into breach trends.<br>• High manual effort to compile compliance reports. |
| **GAINS** | • Automatically generated audit logs of justifications.<br>• Real-time dashboards showing compliance and breach reasons.<br>• An automated manager approval queue for justifications. |

---

### Persona 3: The ServiceNow System Administrator (The Architect)
*Responsible for keeping the platform stable, performant, and easy to upgrade.*

| Category | Details |
| :--- | :--- |
| **SAYS** | *"We must avoid custom scripts wherever possible. Upgradeability is our top priority."*<br>*"Every new field or policy we add must be modular and secure."* |
| **THINKS** | *If we write custom client scripts for this, it will break during the next ServiceNow upgrade (e.g., Washington/Xanadu).*<br>*I want to use Flow Designer and UI Policies so it's easy to maintain.* |
| **DOES** | Reviews configuration requests. Builds flows, Virtual Agent topics, and UI policies. Restricts access control lists (ACLs) to secure fields. |
| **FEELS** | Protective of platform integrity, wary of custom code, and eager to leverage native ServiceNow features. |
| **PAINS** | • Legacy code maintenance.<br>• Slow load times on forms due to heavy client-side scripting.<br>• Broken integrations during platform upgrades. |
| **GAINS** | • Zero-code solutions utilizing Flow Designer and ServiceNow Virtual Agent Designer.<br>• Clean security model using standard ServiceNow Roles and ACLs.<br>• Easy configuration tables for managers to edit thresholds without admin support. |

---

## 3. Ideation: System Architecture & Workflow

Here is how the components interact in a ServiceNow-native, zero-code manner:

```mermaid
sequenceDiagram
    autonumber
    participant Ticket as Incident / SLA Engine
    participant Agent as IT Support Agent
    participant VA as ServiceNow Virtual Agent
    participant Manager as Manager / Governance Dashboard
    
    Ticket->>Ticket: SLA reaches Warning Threshold (e.g., 75% elapsed)
    Ticket->>VA: Trigger Flow (Proactive VA Alert)
    VA->>Agent: Conversational Alert: "Ticket INC00123 is at 75%. Action required!"
    alt Agent takes action (Resolves or Pauses)
        Agent->>Ticket: Update status / Resolve
        Ticket->>Ticket: SLA pauses or completes (Compliant)
    else SLA approaches/breaches threshold
        VA->>Agent: "SLA has breached or is critical. Please provide a mandatory justification."
        Agent->>VA: Submits Justification (Selects Category + Comments)
        VA->>Ticket: Write justification to Ticket Audit Log (Read-only)
        Ticket->>Manager: Update Executive Dashboard & Trigger Approval Task
        Manager->>Ticket: Approve / Acknowledge justification
    end
```

### Feature Ideation Matrix

| Feature Area | Solution Idea (How it works in ServiceNow) | Value Add / Impact |
| :--- | :--- | :--- |
| **Early Awareness** | **Flow Designer + Virtual Agent Integration**: When an SLA percentage exceeds 75%, a Flow runs to send an interactive push notification via Slack, Teams, or ServiceNow Virtual Agent. | Replaces ignored emails with direct, instant interactive chat nudges. |
| **Mandatory Justification** | **ServiceNow UI Policies & Data Policies**: If a ticket reaches a warning state, the UI Policy makes a custom `u_sla_justification_reason` field visible and mandatory before the ticket can be resolved or saved. | Guarantees compliance data is captured at the source before tickets are closed. |
| **Conversational Governance** | **Virtual Agent Topic Flow**: A custom conversation tree that prompts the agent: *"I see INC00123 has breached. Is this due to: A) Vendor delay, B) Customer response, C) Understaffing?"* The selected option writes directly to the record. | Lowers friction for agents. Justification can be done on-the-go via mobile or chat client. |
| **Security & Integrity** | **Access Control Lists (ACLs)**: Ensure that once a justification is submitted, only ServiceNow users with the `u_sla_governor` or `manager` role can edit it, while resolvers only have write access during the breach window. | Creates an immutable audit trail, preventing agents from retroactively altering justification reasons to hide performance issues. |
| **Analytics & Reporting** | **Performance Analytics Dashboard**: Native ServiceNow reports visualized on a workspace dashboard showing compliance rates over time, breach reasons by assignment group, and average resolution times. | Provides executives with immediate bottlenecks (e.g., "Our primary delay reason is Vendor dependency, which accounts for 60% of breaches"). |

---

## 4. ServiceNow Implementation Roadmap (Zero-Code Blueprint)

To build this in ServiceNow without writing custom JavaScript:

### Step 1: SLA Definitions & Thresholds
* Configure **SLA Definitions** (`key_sla`) for *Response* and *Resolution*.
* Set **SLA Workflow** to fire events at 50% (Info), 75% (Warning), and 100% (Breached).

### Step 2: Flow Designer (Trigger Actions)
* **Trigger**: When an SLA record (`task_sla`) changes, and stage is `In_Progress` and percentage elapsed is $\ge 75\%$.
* **Action**: 
  1. Look up the assigned agent's User Profile.
  2. Invoke ServiceNow **Virtual Agent** API / Send notification block to the assignee.
  3. Update target Incident record flag `u_requires_justification` to `True`.

### Step 3: UI Policies (Form Controls)
* Create a **UI Policy** on the Incident (`incident`) table:
  * **Conditions**: `u_requires_justification` IS `True` AND SLA is Breached.
  * **Actions**: 
    * Make fields `u_justification_reason` (Choice list) and `u_justification_details` (String) **visible** and **mandatory**.
    * Make SLA progress fields **read-only**.

### Step 4: Virtual Agent Topic (Conversational Dialog)
* Design a topic in **Virtual Agent Designer**:
  * Greeting: *"Hi [Agent Name], Ticket [INC00123] is at risk of SLA Breach. Can you update me?"*
  * Prompt for choices: User selects from a dropdown (e.g., "Awaiting User Input", "Third Party Delay", "High Complexity").
  * Prompt for comments: Text input.
  * Action step: Write fields back to the incident record and clear the `u_requires_justification` check.

### Step 5: Dashboard & Reporting
* Create a dedicated **ServiceNow Dashboard** containing:
  * Single Score widget: *Current SLA Compliance Rate (%)*.
  * Bar Chart: *Breach Reasons by Assignment Group*.
  * Pivot Table: *List of justification statements pending manager approval*.
