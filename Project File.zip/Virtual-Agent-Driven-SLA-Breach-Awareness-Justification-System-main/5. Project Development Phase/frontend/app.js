const state = {
  view: 'overview',
  users: [],
  currentUser: null,
  dashboard: null,
  incidents: [],
  notifications: [],
  filters: { search: '', status: 'all', assignee: 'all' },
  va: { incidentId: null, messages: [], step: 'idle', reason: '' }
};

const root = document.querySelector('#view-root');
const modalRoot = document.querySelector('#modal-root');
const toastRoot = document.querySelector('#toast-root');
const titles = { overview: 'Overview', incidents: 'Incidents', agent: 'Virtual Agent', reports: 'Reports', admin: 'Administration' };

function esc(value = '') {
  return String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[char]);
}

function api(path, options = {}) {
  const headers = { ...(options.headers || {}), 'x-demo-user-id': state.currentUser?.id || 'u-maya' };
  if (options.body && !headers['content-type']) headers['content-type'] = 'application/json';
  return fetch(path, { ...options, headers }).then(async (response) => {
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.error || 'Something went wrong. Please try again.');
    return body;
  });
}

function statusClass(status) { return `status-${String(status).toLowerCase().replaceAll(' ', '-')}`; }
function statusColor(value) { return value >= 100 ? '#c14444' : value >= 90 ? '#c77d12' : value >= 80 ? '#d29424' : value >= 70 ? '#467abc' : '#15805e'; }
function priorityClass(priority) { return `priority-${String(priority).toLowerCase()}`; }
function relativeTime(value) {
  const minutes = Math.max(0, Math.round((Date.now() - new Date(value).getTime()) / 60000));
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.round(minutes / 60);
  return hours < 24 ? `${hours}h ago` : `${Math.round(hours / 24)}d ago`;
}
function dueText(incident) {
  if (incident.timeRemainingMinutes < 0) return `breached ${Math.abs(incident.timeRemainingMinutes)}m ago`;
  if (incident.timeRemainingMinutes < 60) return `${incident.timeRemainingMinutes}m remaining`;
  return `${Math.ceil(incident.timeRemainingMinutes / 60)}h remaining`;
}
function toast(message, type = '') {
  const item = document.createElement('div');
  item.className = `toast ${type}`;
  item.textContent = message;
  toastRoot.append(item);
  setTimeout(() => item.remove(), 4200);
}

async function refreshData() {
  const [dashboard, incidents, notifications] = await Promise.all([
    api('/api/dashboard'),
    api('/api/incidents'),
    api('/api/notifications')
  ]);
  state.dashboard = dashboard;
  state.incidents = incidents.incidents;
  state.notifications = notifications.notifications;
  document.querySelector('#notification-count').textContent = state.notifications.length;
  document.querySelector('#notification-count').style.display = state.notifications.length ? 'grid' : 'none';
  document.querySelector('#risk-badge').textContent = dashboard.totals.atRisk + dashboard.totals.breached;
}

async function initialise() {
  try {
    const identity = await api('/api/users');
    state.users = identity.users;
    state.currentUser = identity.currentUser;
    renderUserSelector();
    await refreshData();
    render();
  } catch (error) {
    root.innerHTML = `<div class="empty-state"><span style="font-size:32px">◌</span><strong>We could not connect to the SLA workspace.</strong><span>${esc(error.message)} Start the backend, then refresh this page.</span></div>`;
  }
}

function renderUserSelector() {
  const select = document.querySelector('#user-select');
  select.innerHTML = state.users.map((user) => `<option value="${esc(user.id)}" ${user.id === state.currentUser.id ? 'selected' : ''}>${esc(user.name)} · ${esc(user.role)}</option>`).join('');
  document.querySelector('#user-avatar').textContent = state.currentUser.initials;
  document.querySelector('#user-avatar').title = state.currentUser.name;
}

function heading(eyebrow, title, description, actions = '') {
  return `<div class="page-heading"><div><p class="eyebrow">${eyebrow}</p><h1>${title}</h1><p>${description}</p></div>${actions ? `<div class="heading-actions">${actions}</div>` : ''}</div>`;
}

function render() {
  document.querySelector('#breadcrumb-current').textContent = titles[state.view];
  document.querySelectorAll('.nav-link').forEach((button) => button.classList.toggle('active', button.dataset.view === state.view));
  if (state.view === 'overview') root.innerHTML = overviewView();
  if (state.view === 'incidents') root.innerHTML = incidentsView();
  if (state.view === 'agent') root.innerHTML = agentView();
  if (state.view === 'reports') root.innerHTML = reportsView();
  if (state.view === 'admin') root.innerHTML = adminView();
  root.focus({ preventScroll: true });
}

function overviewView() {
  const d = state.dashboard;
  const p = d.performance;
  const totalPerformance = p.onTrack + p.watch + p.critical + p.breached || 1;
  const firstRows = state.incidents.filter((item) => item.status !== 'Resolved').slice(0, 5);
  return `
    ${heading('SLA GOVERNANCE WORKSPACE', 'Good morning, ' + esc(state.currentUser.name.split(' ')[0]) + '.', 'Monitor SLA exposure, capture accountability, and keep every breach decision audit-ready.', `<button class="button button-secondary" data-action="open-help">How it works</button><button class="button button-primary" data-action="go-agent">✦ Open Virtual Agent</button>`)}
    <div class="stats-grid">
      ${statCard('Active incidents', d.totals.active, 'Currently in progress', '◫', '#2d6cdf', '#e9f0ff')}
      ${statCard('SLA at risk', d.totals.atRisk, `${d.totals.atRisk ? 'Action required now' : 'No immediate action'}`, '◷', '#c77d12', '#fff3da')}
      ${statCard('SLA breached', d.totals.breached, d.totals.needsJustification ? `${d.totals.needsJustification} awaiting justification` : 'All are documented', '!', '#c14444', '#fff0f0')}
      ${statCard('Justifications', d.totals.justified, 'Recorded for management review', '✓', '#15805e', '#e4f5ee')}
    </div>
    <div class="dashboard-grid">
      <div class="stack">
        <section class="card">
          <div class="card-header"><div><h2 class="card-title">SLA attention queue</h2><p class="card-subtitle">Incidents ordered by SLA consumption. Alerts start at 80%.</p></div><button class="text-link" data-action="go-incidents">View all incidents →</button></div>
          ${firstRows.map(overviewIncidentRow).join('') || '<div class="empty-state">No active incidents.</div>'}
        </section>
        <section class="card">
          <div class="card-header"><div><h2 class="card-title">Recent audit activity</h2><p class="card-subtitle">Automatic work notes and agent accountability events.</p></div></div>
          ${d.recentActivity.map((item) => `<div class="activity"><div class="activity-icon">${item.author === 'System' ? '◌' : '✓'}</div><div><p><b>${esc(item.incidentId)}</b> · ${esc(item.text)}</p><small>${esc(item.author)} · ${relativeTime(item.createdAt)}</small></div></div>`).join('')}
        </section>
      </div>
      <div class="stack">
        <section class="card">
          <div class="card-header"><div><h2 class="card-title">SLA health</h2><p class="card-subtitle">Active work by risk level</p></div></div>
          <div class="donut-wrap"><div class="donut" style="--angle:${Math.round((p.onTrack / totalPerformance) * 100)}%"><div class="donut-center"><strong>${Math.round((p.onTrack / totalPerformance) * 100)}%</strong><small>on track</small></div></div><div class="legend">
            ${legend('On track', p.onTrack, '#15805e')}${legend('Watch', p.watch, '#d29424')}${legend('Critical', p.critical, '#c77d12')}${legend('Breached', p.breached, '#c14444')}
          </div></div>
        </section>
        <section class="card">
          <div class="card-header"><div><h2 class="card-title">Team accountability</h2><p class="card-subtitle">Assigned active work and SLA compliance</p></div></div>
          ${d.byAssignee.map((entry) => `<div class="team-row"><div class="person"><span class="avatar">${esc(entry.user.initials)}</span><div><div class="person-name">${esc(entry.user.name)}</div><div class="person-team">${esc(entry.user.team)}</div></div></div><div class="team-count">${entry.atRisk ? `<b>${entry.atRisk}</b> risk` : 'Clear'}</div><div class="team-compliance">${entry.compliance}%</div></div>`).join('')}
        </section>
      </div>
    </div>`;
}

function statCard(label, value, footer, symbol, color, soft) {
  return `<div class="stat-card" style="--stat-color:${color};--stat-soft:${soft}"><div class="stat-top"><span class="stat-symbol">${symbol}</span>${label}</div><div class="stat-value">${value}</div><div class="stat-footer"><strong>${footer}</strong></div></div>`;
}
function legend(label, value, color) { return `<div class="legend-item"><span><i class="legend-dot" style="--dot:${color}"></i>${label}</span><b>${value}</b></div>`; }
function overviewIncidentRow(item) {
  return `<div class="incident-row"><div><div class="incident-id">${esc(item.id)} · ${esc(item.priority)}</div><div class="incident-description">${esc(item.shortDescription)}</div></div><div class="incident-service">${esc(item.assignedUser.name.split(' ')[0])}<br><span style="color:#8da0a5;font-size:10px">${esc(item.service)}</span></div><div><span class="${statusClass(item.breachStatus)} status-pill">${esc(item.breachStatus)}</span></div><div class="sla-cell" style="--bar:${statusColor(item.slaPercentage)}">${item.slaPercentage}%<div class="progress"><i style="width:${Math.min(item.slaPercentage, 100)}%"></i></div></div><button class="row-action" data-open-agent="${esc(item.id)}">Review</button></div>`;
}

function incidentsView() {
  const filtered = filterIncidents();
  return `
    ${heading('INCIDENT WORKSPACE', 'SLA attention center', 'Identify incidents approaching breach, notify assignees, and record explanations in one place.', `<button class="button button-secondary" data-action="refresh">↻ Refresh</button>${state.currentUser.canAdmin ? '<button class="button button-primary" data-action="go-admin">+ Add temporary incident</button>' : ''}`)}
    <div class="filters"><div class="search-box"><span>⌕</span><input id="incident-search" value="${esc(state.filters.search)}" placeholder="Search incident, service, or description" /></div><select id="status-filter" class="filter-select"><option value="all">All SLA states</option>${['On track','Watch','At risk','Breached','Met'].map((status) => `<option ${state.filters.status === status ? 'selected' : ''} value="${status}">${status}</option>`).join('')}</select><select id="assignee-filter" class="filter-select"><option value="all">All assignees</option>${state.users.filter((u) => u.role === 'IT Agent').map((user) => `<option value="${user.id}" ${state.filters.assignee === user.id ? 'selected' : ''}>${esc(user.name)}</option>`).join('')}</select></div>
    <section class="table-card card"><table class="incident-table"><thead><tr><th>Incident</th><th>Priority</th><th>Assigned to</th><th>SLA health</th><th>Status</th><th>Accountability</th><th></th></tr></thead><tbody>${filtered.length ? filtered.map(incidentTableRow).join('') : `<tr><td colspan="7"><div class="empty-state"><strong>No incidents match these filters.</strong>Try changing the search or SLA state.</div></td></tr>`}</tbody></table></section>`;
}

function filterIncidents() {
  const needle = state.filters.search.toLowerCase().trim();
  return state.incidents.filter((item) => (!needle || `${item.id} ${item.shortDescription} ${item.service}`.toLowerCase().includes(needle)) && (state.filters.status === 'all' || item.breachStatus === state.filters.status) && (state.filters.assignee === 'all' || item.assignedTo === state.filters.assignee));
}
function incidentTableRow(item) {
  const accountability = item.justification ? '<span class="status-pill status-met">Submitted</span>' : item.slaPercentage >= 100 ? '<span class="status-pill status-breached">Required</span>' : item.acknowledged ? '<span class="status-pill status-watch">Acknowledged</span>' : '<span style="color:#8da0a5;font-size:10px">Not required</span>';
  return `<tr><td><div class="table-incident">${esc(item.id)}</div><div class="table-desc">${esc(item.shortDescription)}</div><div class="table-sub">${esc(item.service)} · ${esc(item.status)}</div></td><td><span class="priority ${priorityClass(item.priority)}">${esc(item.priority)}</span></td><td><div class="assignee-cell"><span class="avatar">${esc(item.assignedUser.initials)}</span><span>${esc(item.assignedUser.name)}</span></div></td><td><div class="inline-sla" style="--bar:${statusColor(item.slaPercentage)}"><b>${item.slaPercentage}%</b><span class="table-sub">${dueText(item)}</span><div class="progress"><i style="width:${Math.min(100,item.slaPercentage)}%"></i></div></div></td><td><span class="status-pill ${statusClass(item.breachStatus)}">${esc(item.breachStatus)}</span></td><td>${accountability}</td><td><button class="row-action" data-open-agent="${esc(item.id)}">${item.assignedTo === state.currentUser.id && item.slaPercentage >= 80 && !item.justification ? 'Respond' : 'View'}</button></td></tr>`;
}

function agentView() {
  const eligible = state.incidents.filter((item) => item.assignedTo === state.currentUser.id && item.status !== 'Resolved' && item.slaPercentage >= 80 && !item.justification);
  if (!state.currentUser || state.currentUser.role !== 'IT Agent') {
    return `${heading('VIRTUAL AGENT', 'SLA accountability conversation', 'The Virtual Agent is intentionally restricted to the incident assignee. Managers can view submitted results in Reports.')}
      <section class="card"><div class="empty-state"><span style="font-size:34px">✦</span><strong>Assignee access required</strong><span>Switch to Maya Patel or Daniel Kim in the demo profile menu to experience the guided SLA acknowledgement and justification conversation.</span></div></section>`;
  }
  if (!state.va.incidentId && eligible[0]) selectVAIncident(eligible[0].id);
  const selected = state.incidents.find((item) => item.id === state.va.incidentId);
  return `${heading('VIRTUAL AGENT', 'SLA awareness assistant', 'A guided, audit-ready conversation that helps the assigned agent acknowledge SLA exposure and explain the blocker.')}
    <section class="card agent-layout"><aside class="agent-side"><h2>Your SLA attention queue</h2><p>Only incidents assigned to ${esc(state.currentUser.name)} are available here.</p>${eligible.length ? eligible.map((item) => `<button class="agent-incident ${item.id === state.va.incidentId ? 'selected' : ''}" data-va-select="${esc(item.id)}"><div class="agent-incident-top"><span>${esc(item.id)}</span><span>${item.slaPercentage}%</span></div><p>${esc(item.shortDescription)}</p><small>${esc(item.breachStatus)} · ${dueText(item)}</small></button>`).join('') : '<div class="empty-state" style="padding:22px 5px"><strong>All clear.</strong><span>There are no assigned at-risk incidents awaiting a response.</span></div>'}</aside>
      <div class="agent-chat"><div class="agent-chat-header"><div class="bot-avatar">✦</div><div><h2>Orbit Virtual Agent</h2><p><span class="online-dot"></span>Online · SLA governance guide</p></div></div>${selected ? renderChat(selected) : '<div class="empty-state"><span style="font-size:32px">✓</span><strong>No response needed</strong><span>Select an assigned at-risk incident when one is available.</span></div>'}</div>
    </section>`;
}

function selectVAIncident(id) {
  state.va = { incidentId: id, messages: [], step: 'idle', reason: '' };
}
function renderChat(incident) {
  const messages = state.va.messages.map((message) => `<div class="chat-message ${message.from === 'user' ? 'user' : ''}"><div class="mini-avatar">${message.from === 'user' ? esc(state.currentUser.initials) : '✦'}</div><div><div class="bubble">${esc(message.text)}</div><div class="chat-time">${message.from === 'user' ? 'You' : 'Orbit VA'} · ${message.time}</div></div></div>`).join('');
  let interaction = '';
  if (state.va.step === 'idle') interaction = `<div class="chat-card"><p>Selected incident</p><strong>${esc(incident.id)} · ${incident.slaPercentage}% SLA consumed</strong><p>${esc(incident.shortDescription)}</p></div><div class="chat-actions"><button class="button button-primary" data-va-action="start">Begin SLA review</button></div>`;
  if (state.va.step === 'acknowledge') interaction = `<div class="chat-actions"><button class="button button-primary" data-va-action="acknowledge">I acknowledge this alert</button><button class="button button-secondary" data-action="go-incidents">Review incident first</button></div>`;
  if (state.va.step === 'reason') interaction = `<div class="chat-actions">${['Third-party dependency', 'Technical complexity', 'Awaiting requester', 'Resource constraint', 'Incorrect routing', 'Other'].map((reason) => `<button class="reason-option" data-va-reason="${esc(reason)}">${esc(reason)}</button>`).join('')}</div>`;
  if (state.va.step === 'details') interaction = `<div class="chat-input-area"><label class="sr-only" for="justification-details">Justification details</label><textarea id="justification-details" placeholder="Describe the blocker, action already taken, and next expected action…"></textarea><div class="chat-input-foot"><small>This will be added to the incident work notes.</small><button class="button button-primary" data-va-action="submit">Submit justification</button></div></div>`;
  if (state.va.step === 'complete') interaction = `<div class="chat-card" style="background:#eaf8f2;border-color:#c6eadb"><p style="color:#167452">✓ Accountability record complete</p><strong>Your justification is saved in the audit trail.</strong></div><div class="chat-actions"><button class="button button-secondary" data-action="go-reports">View reporting</button></div>`;
  return `<div id="chat-body" class="agent-chat-body">${messages || '<div class="chat-message"><div class="mini-avatar">✦</div><div><div class="bubble">Welcome. I’ll help you record your SLA acknowledgement in a clear, consistent way.</div><div class="chat-time">Orbit VA · now</div></div></div>'}${interaction}</div>`;
}

function reportsView() {
  const rows = state.incidents.filter((item) => item.status !== 'Resolved' || item.slaPercentage >= 100);
  const submitted = rows.filter((item) => item.justification).length;
  const required = rows.filter((item) => item.slaPercentage >= 100).length;
  return `
    ${heading('REPORTING & DASHBOARDS', 'SLA governance report', 'Use this view to review SLA exposure, breach reasons, and justification compliance across the team.', '<button class="button button-secondary" data-action="export-report">⇩ Export CSV</button>')}
    <div class="report-summary"><div class="summary-strip"><strong>${state.dashboard.totals.active}</strong><span>Active incidents monitored</span></div><div class="summary-strip"><strong>${required ? Math.round((submitted / required) * 100) : 100}%</strong><span>Breach justification compliance</span></div><div class="summary-strip"><strong>${submitted}</strong><span>Audit-ready reasons submitted</span></div></div>
    <section class="card table-card"><table class="incident-table report-table"><thead><tr><th>Incident & service</th><th>Assignee</th><th>SLA result</th><th>Justification</th><th>Reason</th><th>Latest activity</th></tr></thead><tbody>${rows.map((item) => `<tr><td><div class="table-incident">${esc(item.id)}</div><div class="table-desc">${esc(item.service)}</div></td><td>${esc(item.assignedUser.name)}</td><td><span class="status-pill ${statusClass(item.breachStatus)}">${esc(item.breachStatus)} · ${item.slaPercentage}%</span></td><td>${item.justification ? '<span class="status-pill status-met">Submitted</span>' : item.slaPercentage >= 100 ? '<span class="status-pill status-breached">Required</span>' : '<span style="color:#8da0a5">—</span>'}</td><td>${item.justification ? esc(item.justification.reason) : '—'}</td><td>${relativeTime(item.workNotes[item.workNotes.length - 1]?.createdAt)}</td></tr>`).join('')}</tbody></table></section>
    <div class="report-note"><strong>Supabase reporting:</strong> this dashboard reads persistent SLA records from the connected database. Use the CSV export when you need to share the current report outside the workspace.</div>`;
}

function adminView() {
  const agents = state.users.filter((user) => user.role === 'IT Agent');
  const allowed = state.currentUser.canAdmin;
  return `
    ${heading('ADMINISTRATION', 'Configuration & persistent data', 'Add an incident to validate notifications, the Virtual Agent, and reporting in the connected Supabase database.')}
    <div class="admin-layout"><section class="card"><div class="card-header"><div><h2 class="card-title">Add an incident</h2><p class="card-subtitle">Available to the ServiceNow Administrator demo profile only.</p></div></div>${allowed ? `<form id="incident-form"><div class="form-grid"><div class="field full"><label for="new-description">Short description</label><input required id="new-description" name="shortDescription" placeholder="Example: Payroll portal response is slow" /></div><div class="field"><label for="new-service">Service</label><input required id="new-service" name="service" placeholder="Example: Payroll Services" /></div><div class="field"><label for="new-priority">Priority</label><select id="new-priority" name="priority"><option>P1</option><option selected>P2</option><option>P3</option></select></div><div class="field"><label for="new-assignee">Assign to</label><select id="new-assignee" name="assignedTo">${agents.map((user) => `<option value="${user.id}">${esc(user.name)} · ${esc(user.team)}</option>`).join('')}</select></div><div class="field"><label for="new-sla">SLA consumed (%)</label><input required id="new-sla" type="number" name="slaPercentage" min="0" max="200" value="85" /><span class="form-hint">Use 80+ to create an alert; 100+ is breached.</span></div><div class="field"><label for="new-minutes">Minutes to SLA due</label><input required id="new-minutes" type="number" name="minutesToBreach" min="-1440" max="10080" value="60" /><span class="form-hint">Use a negative value for already breached.</span></div></div><div class="form-actions"><span class="permission-note"><strong>Persistent:</strong> this record is saved in Supabase until you remove it.</span><button class="button button-primary" type="submit">+ Create incident</button></div></form>` : `<div class="empty-state"><span style="font-size:32px">⚙</span><strong>Administrator access required</strong><span>Switch the demo profile to Alex Morgan to add incidents. The backend also prevents non-admin requests.</span></div>`}</section>
    <section class="card"><div class="card-header"><div><h2 class="card-title">Requirement coverage</h2><p class="card-subtitle">Included in this deployable demo</p></div></div><div class="admin-checklist"><div class="check-row"><span class="check">✓</span><div><strong>SLA percentage & breach status</strong><span>Tracked on every incident and surfaced at 80%+.</span></div></div><div class="check-row"><span class="check">✓</span><div><strong>Virtual Agent interaction</strong><span>Guided acknowledgement, reason selection, and explanation capture.</span></div></div><div class="check-row"><span class="check">✓</span><div><strong>Incident automation</strong><span>Each acknowledgement and justification creates an audit work note.</span></div></div><div class="check-row"><span class="check">✓</span><div><strong>Notifications & reporting</strong><span>Assignee alerts, team dashboard, and CSV report export.</span></div></div><div class="check-row"><span class="check">✓</span><div><strong>Access control</strong><span>Server validates assignee-only responses and admin-only creation.</span></div></div></div></section></div>`;
}

async function handleVA(action, extra = {}) {
  const selected = state.incidents.find((item) => item.id === state.va.incidentId);
  if (!selected) return;
  try {
    if (action === 'start') addMessage('user', `Begin review for ${selected.id}.`);
    if (action === 'acknowledge') addMessage('user', 'I acknowledge this alert.');
    if (action === 'reason') addMessage('user', extra.reason);
    if (action === 'submit') addMessage('user', 'Submitting my justification.');
    render();
    const response = await api('/api/virtual-agent/message', { method: 'POST', body: JSON.stringify({ incidentId: selected.id, action, ...extra }) });
    addMessage('bot', response.message);
    state.va.step = response.next;
    if (action === 'reason') state.va.reason = extra.reason;
    if (response.incident) replaceIncident(response.incident);
    await refreshData();
    render();
    requestAnimationFrame(() => document.querySelector('#chat-body')?.scrollTo({ top: 9999, behavior: 'smooth' }));
  } catch (error) {
    toast(error.message, 'error');
    render();
  }
}
function addMessage(from, text) { state.va.messages.push({ from, text, time: 'now' }); }
function replaceIncident(updated) { const index = state.incidents.findIndex((item) => item.id === updated.id); if (index >= 0) state.incidents[index] = updated; }

function openNotifications() {
  const list = state.notifications;
  modalRoot.innerHTML = `<div class="modal-backdrop" data-close-modal><section class="modal" role="dialog" aria-modal="true" aria-label="SLA notifications"><div class="modal-header"><div><h2>SLA notifications</h2><p>${list.length ? 'Alerts for your assigned incidents that require attention.' : 'You have no outstanding SLA alerts.'}</p></div><button class="close-button" data-close-modal aria-label="Close">×</button></div><div class="notification-list">${list.length ? list.map((notification) => `<div class="notification-item" style="--severity:${notification.severity === 'critical' ? '#c14444' : notification.severity === 'high' ? '#c77d12' : '#d29424'}"><strong>${esc(notification.title)}</strong><span>${esc(notification.message)}</span><button class="text-link" data-open-agent="${esc(notification.incidentId)}" data-close-modal>Open Virtual Agent →</button></div>`).join('') : '<div class="empty-state" style="padding:20px">No alerts for the selected profile.</div>'}</div></section></div>`;
}
function openHelp() {
  modalRoot.innerHTML = `<div class="modal-backdrop" data-close-modal><section class="modal" role="dialog" aria-modal="true" aria-label="How this demo works"><div class="modal-header"><h2>How this workspace works</h2><button class="close-button" data-close-modal aria-label="Close">×</button></div><p>The app starts with sample incidents in server memory. SLA risk begins at 80%; assignees receive alerts and can use the Virtual Agent to acknowledge the issue, choose a reason, and provide their justification.</p><p>The backend adds each response to the incident audit work notes and blocks anyone other than the assigned agent from submitting it. Switch profiles from the top menu to see each role’s view.</p><p><strong>Nothing is stored permanently.</strong> New incidents and responses disappear on a server restart or redeploy. Browser refreshes keep the temporary data while the server is still running.</p></section></div>`;
}
function exportReport() {
  const header = ['Incident', 'Service', 'Priority', 'Assignee', 'SLA percentage', 'Breach status', 'Justification status', 'Reason'];
  const lines = state.incidents.map((item) => [item.id, item.service, item.priority, item.assignedUser.name, item.slaPercentage, item.breachStatus, item.justification ? 'Submitted' : item.slaPercentage >= 100 ? 'Required' : 'Not required', item.justification?.reason || '']);
  const csv = [header, ...lines].map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(',')).join('\n');
  const link = document.createElement('a');
  link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  link.download = `sla-governance-report-${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
  toast('The current in-memory SLA report was exported.', 'success');
}

document.addEventListener('click', async (event) => {
  const nav = event.target.closest('[data-view]');
  if (nav) { state.view = nav.dataset.view; document.querySelector('#app-shell').classList.remove('menu-open'); render(); return; }
  if (event.target.closest('#menu-button')) { document.querySelector('#app-shell').classList.toggle('menu-open'); return; }
  if (event.target.closest('#notification-button')) { openNotifications(); return; }
  if (event.target.closest('[data-close-modal]')) { modalRoot.innerHTML = ''; return; }
  const openAgent = event.target.closest('[data-open-agent]');
  if (openAgent) { selectVAIncident(openAgent.dataset.openAgent); state.view = 'agent'; modalRoot.innerHTML = ''; render(); return; }
  const select = event.target.closest('[data-va-select]');
  if (select) { selectVAIncident(select.dataset.vaSelect); render(); return; }
  const vaAction = event.target.closest('[data-va-action]');
  if (vaAction) {
    if (vaAction.dataset.vaAction === 'submit') { const details = document.querySelector('#justification-details')?.value || ''; await handleVA('submit', { reason: state.va.reason, details }); }
    else await handleVA(vaAction.dataset.vaAction);
    return;
  }
  const reason = event.target.closest('[data-va-reason]');
  if (reason) { await handleVA('reason', { reason: reason.dataset.vaReason }); return; }
  const action = event.target.closest('[data-action]')?.dataset.action;
  if (!action) return;
  if (action === 'open-help') openHelp();
  if (action === 'go-agent') { state.view = 'agent'; render(); }
  if (action === 'go-incidents') { state.view = 'incidents'; render(); }
  if (action === 'go-reports') { state.view = 'reports'; render(); }
  if (action === 'go-admin') { state.view = 'admin'; render(); }
  if (action === 'refresh') { await refreshData(); render(); toast('SLA workspace refreshed.', 'success'); }
  if (action === 'export-report') exportReport();
});

document.addEventListener('input', (event) => {
  if (event.target.id === 'incident-search') { state.filters.search = event.target.value; render(); document.querySelector('#incident-search')?.focus(); }
});
document.addEventListener('change', async (event) => {
  if (event.target.id === 'status-filter') { state.filters.status = event.target.value; render(); }
  if (event.target.id === 'assignee-filter') { state.filters.assignee = event.target.value; render(); }
  if (event.target.id === 'user-select') {
    state.currentUser = state.users.find((user) => user.id === event.target.value);
    state.va = { incidentId: null, messages: [], step: 'idle', reason: '' };
    renderUserSelector();
    await refreshData();
    render();
    toast(`Viewing the workspace as ${state.currentUser.name}.`);
  }
});
document.addEventListener('submit', async (event) => {
  if (event.target.id !== 'incident-form') return;
  event.preventDefault();
  const form = new FormData(event.target);
  const body = Object.fromEntries(form.entries());
  try {
    const response = await api('/api/incidents', { method: 'POST', body: JSON.stringify(body) });
    await refreshData();
    state.view = 'incidents';
    render();
    toast(`${response.incident.id} was saved to Supabase.`, 'success');
  } catch (error) { toast(error.message, 'error'); }
});

initialise();
