# Orbit SLA — User & Working Guide

## 1. What this website does

Orbit SLA is a **Virtual Agent–Driven SLA Breach Awareness & Justification System**. It helps IT teams notice incidents that are close to an SLA breach, notify the assigned agent, capture a clear reason for the delay, and provide managers with an audit-ready view of SLA performance.

### Main purpose

- Detect incidents at risk of breaching their SLA (80% SLA consumption or higher).
- Notify the assigned IT agent before a breach happens.
- Guide the assignee through a Virtual Agent conversation.
- Record acknowledgement, reason, and explanation as incident work notes.
- Let managers review SLA performance and justification compliance.
- Keep all information in Supabase so it remains available after refreshes and deployments.

## 2. Before first use

### Step 1 — Create the database tables

1. Open your Supabase project dashboard.
2. Select **SQL Editor**.
3. Create a new query.
4. Open `supabase/schema.sql` in this project.
5. Copy all its contents into the Supabase SQL Editor.
6. Click **Run**.

This creates the `sla_users` and `sla_incidents` tables, indexes, and access controls required by the application.

### Step 2 — Confirm environment settings

The backend reads Supabase settings from `.env`:

```text
SUPABASE_URL=https://your-project-ref.supabase.co
SUPABASE_SERVICE_KEY=your-server-only-secret-key
```

Important:

- Never place the secret key in frontend files.
- Never commit `.env` to GitHub.
- When deploying, add the same values to the hosting provider's environment-variable settings.

### Step 3 — Start the website

Open PowerShell in the project folder and run:

```powershell
npm.cmd install
npm.cmd start
```

Open this address in Chrome:

```text
http://localhost:3000
```

On the first successful start, sample users and incidents are inserted only if the database is empty.

## 3. Website areas

| Area | What it is used for |
| --- | --- |
| Overview | View active work, SLA risk, breached incidents, justifications, SLA health, audit activity, and team accountability. |
| Incidents | Search and filter all incidents by SLA status or assignee. Review SLA percentage, priority, owner, and justification state. |
| Virtual Agent | Let an assigned agent acknowledge an SLA alert and submit a breach/risk explanation. |
| Reports | Review SLA performance and justification compliance; export the current report as CSV. |
| Administration | Add incidents to Supabase and review what requirements the demo covers. |

## 4. Demo user roles

Use the profile selector in the top-right corner to switch roles.

### IT agents — Maya Patel and Daniel Kim

IT agents can:

- Receive SLA notifications for incidents assigned to them.
- View their at-risk incidents in the Virtual Agent queue.
- Acknowledge an SLA alert.
- Select a reason and submit a detailed justification.

Only the assigned agent can submit a justification. This rule is checked by the backend, not just hidden in the screen.

### IT manager — Priya Raman

The manager can:

- Monitor SLA exposure from Overview and Reports.
- Review team performance and submitted justifications.
- Export the SLA report.

The manager cannot submit a justification on behalf of an assigned agent.

### ServiceNow administrator — Alex Morgan

The administrator can:

- Review all workspace information.
- Open **Administration**.
- Add a new incident.
- Assign the incident to an IT agent.
- Set the SLA percentage and time remaining.

## 5. Main SLA process

```text
Administrator creates / imports an incident
                ↓
SLA consumption reaches 80% or more
                ↓
Assigned agent sees notification and attention queue
                ↓
Agent opens Virtual Agent and acknowledges the alert
                ↓
Agent selects a reason and explains the blocker / next action
                ↓
System saves the justification and work note in Supabase
                ↓
Manager reviews it in Overview and Reports
```

## 6. How an IT agent uses the Virtual Agent

1. Select **Maya Patel** or **Daniel Kim** in the profile selector.
2. Click the notification bell, or open **Virtual Agent** from the sidebar.
3. Select one of the assigned incidents in the SLA attention queue.
4. Click **Begin SLA review**.
5. Click **I acknowledge this alert**.
6. Choose the reason that best explains the risk or breach.
7. Write the current blocker, work already completed, and the next planned action.
8. Click **Submit justification**.

The application then:

- Marks the incident as acknowledged.
- Saves the reason and explanation.
- Adds a timestamped audit work note.
- Updates dashboards and reports immediately.

## 7. How to add an incident

1. Switch to **Alex Morgan — ServiceNow Administrator**.
2. Open **Administration** in the sidebar.
3. Enter the short description and service.
4. Choose priority and assignee.
5. Enter SLA consumed percentage.
   - `80` or higher creates an SLA attention alert.
   - `100` or higher marks the incident as breached.
6. Enter the minutes remaining to SLA due time.
   - Use a negative value if the SLA is already breached.
7. Click **Create incident**.

The incident is saved to Supabase and remains available after a browser refresh.

## 8. How to use reports

1. Open **Reports**.
2. Review current SLA state, assignee, justification status, and reason.
3. Click **Export CSV** to download the current SLA report.

Use reports for management review, accountability follow-up, and SLA governance discussions.

## 9. Website icon

The Orbit SLA icon is stored at:

```text
frontend/assets/orbit-sla-icon.svg
```

It is used in two places:

- Chrome tab favicon, so users can identify the website among open tabs.
- Sidebar logo, so the workspace has a consistent identity.

To replace it later, use another SVG file with the same filename and refresh the browser.

## 10. Deployment checklist

Before deploying:

1. Run `supabase/schema.sql` in the production Supabase project.
2. Add `SUPABASE_URL` and `SUPABASE_SERVICE_KEY` as secure environment variables on the hosting platform.
3. Do not upload `.env` or expose its key in frontend code.
4. Set the deployment start command to:

   ```text
   npm start
   ```

5. Confirm the deployment provides a `PORT` environment variable; the app automatically uses it.
6. Open the deployed site, create one test incident as administrator, and submit one Virtual Agent justification as its assignee.

## 11. Troubleshooting

| Problem | Solution |
| --- | --- |
| App says Supabase tables are missing | Run `supabase/schema.sql` in Supabase SQL Editor, then restart the app. |
| App cannot connect to Supabase | Check `SUPABASE_URL` and `SUPABASE_SERVICE_KEY` in `.env`. |
| No Virtual Agent incident appears | Switch to an assigned IT agent and use an open incident with SLA percentage of 80 or greater. |
| Cannot submit a justification | Confirm the selected profile is the incident's assignee. |
| Chrome shows the old tab icon | Refresh with `Ctrl + F5`; Chrome may cache favicons. |
| `npm` is blocked by PowerShell policy | Use `npm.cmd install` and `npm.cmd start`. |

## 12. Security note

The current profile switcher is for demonstration and testing. In a production version, replace it with real authentication (for example, Supabase Auth or ServiceNow SSO) and map each logged-in user to an IT agent, manager, or administrator role.
