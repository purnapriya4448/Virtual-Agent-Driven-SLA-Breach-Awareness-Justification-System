# SLA Breach Awareness & Justification System

A full-stack, Supabase-backed demonstration of proactive SLA governance. It has an SLA dashboard, notifications, a guided Virtual Agent, assignee-only justification capture, audit work notes, reporting, and an admin incident form.

## Run locally

1. In Supabase Dashboard, open **SQL Editor** and run [supabase/schema.sql](./supabase/schema.sql).
2. Ensure `.env` contains the project URL and the server-only secret key. A safe template is in `.env.example`.
3. Run:

   ```powershell
   npm.cmd install
   npm.cmd start
   ```

Open `http://localhost:3000`.

## App icon

The reusable icon is at `frontend/assets/orbit-sla-icon.svg`. It is automatically used as the Chrome tab favicon and as the sidebar logo. To change the icon later, replace that SVG while keeping its filename, then refresh the browser (or clear the browser's favicon cache if Chrome keeps the previous tab icon).

For development with automatic server restarts, use `npm run dev`.

## Deploy

This project is a single Node.js service. Set the host's start command to `npm start`; the app listens on `PORT` when provided by the hosting platform, otherwise port `3000`.

## Persistent Supabase data

The backend connects to Supabase using the secret key stored in `.env`; this key is never sent to the browser. On the first successful start, the app adds sample users and incidents only when the tables are empty. Incidents, acknowledgements, justifications, and audit notes now persist through browser refreshes and deployments.

If you deploy the app, add `SUPABASE_URL` and `SUPABASE_SERVICE_KEY` as secure environment variables on the host instead of uploading `.env`.

## Demo users

Use the profile selector in the top-right of the app:

- Maya Patel — IT agent / assignee
- Daniel Kim — IT agent / assignee
- Priya Raman — IT manager
- Alex Morgan — ServiceNow administrator

The API independently enforces that only the assigned agent may submit a justification. The selected demo identity is sent in the `x-demo-user-id` request header.
