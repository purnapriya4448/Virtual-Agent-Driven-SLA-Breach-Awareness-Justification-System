const path = require('path');
const express = require('express');
const data = require('./data');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '100kb' }));
app.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

const asyncRoute = (handler) => (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);

async function currentUser(req) {
  return (await data.getUser(req.get('x-demo-user-id'))) || data.DEFAULT_USERS[0];
}

const requireAdmin = asyncRoute(async (req, res, next) => {
  const user = await currentUser(req);
  if (!user.canAdmin) return res.status(403).json({ error: 'Administrator access is required for this action.' });
  req.user = user;
  next();
});

app.get('/api/health', asyncRoute(async (req, res) => {
  const database = await data.dbHealth();
  res.json({ status: 'ok', storage: database.storage, time: new Date().toISOString() });
}));

app.get('/api/users', asyncRoute(async (req, res) => {
  res.json({ users: await data.listUsers(), currentUser: await currentUser(req) });
}));

app.get('/api/dashboard', asyncRoute(async (req, res) => res.json(await data.getDashboard())));
app.get('/api/incidents', asyncRoute(async (req, res) => res.json({ incidents: await data.listIncidents(req.query) })));
app.get('/api/incidents/:id', asyncRoute(async (req, res) => {
  const incident = await data.getIncident(req.params.id);
  if (!incident) return res.status(404).json({ error: 'Incident not found.' });
  res.json({ incident });
}));
app.get('/api/notifications', asyncRoute(async (req, res) => res.json({ notifications: await data.getNotifications((await currentUser(req)).id) })));
app.get('/api/reports/sla', asyncRoute(async (req, res) => res.json({ generatedAt: new Date().toISOString(), rows: await data.getReport() })));

app.post('/api/incidents', requireAdmin, asyncRoute(async (req, res) => {
  const { shortDescription, service, priority, assignedTo, slaPercentage, minutesToBreach } = req.body;
  const assignee = await data.getUser(assignedTo);
  if (!shortDescription?.trim() || !service?.trim() || !priority || !assignee || !Number.isFinite(Number(slaPercentage)) || !Number.isFinite(Number(minutesToBreach))) {
    return res.status(400).json({ error: 'Enter a description, service, priority, valid assignee, SLA percentage, and minutes remaining.' });
  }
  if (Number(slaPercentage) < 0 || Number(slaPercentage) > 200 || Number(minutesToBreach) < -1440 || Number(minutesToBreach) > 10080) {
    return res.status(400).json({ error: 'SLA percentage must be 0–200 and minutes must be between -1440 and 10080.' });
  }
  res.status(201).json({ incident: await data.createIncident(req.body) });
}));

app.post('/api/incidents/:id/acknowledge', asyncRoute(async (req, res) => {
  const result = await data.acknowledgeIncident(req.params.id, (await currentUser(req)).id);
  if (result.error) return res.status(result.status).json({ error: result.error });
  res.json(result);
}));

app.post('/api/incidents/:id/justification', asyncRoute(async (req, res) => {
  const result = await data.saveJustification(req.params.id, (await currentUser(req)).id, req.body);
  if (result.error) return res.status(result.status).json({ error: result.error });
  res.json(result);
}));

// The Virtual Agent is stateless in the browser; all durable acknowledgement and
// justification updates are enforced and written by the server to Supabase.
app.post('/api/virtual-agent/message', asyncRoute(async (req, res) => {
  const { incidentId, action, reason, details } = req.body;
  const user = await currentUser(req);
  const incident = await data.getIncident(incidentId);
  if (!incident) return res.status(404).json({ error: 'Choose an incident before starting the Virtual Agent.' });
  if (incident.assignedTo !== user.id) return res.status(403).json({ error: 'This Virtual Agent conversation is available only to the assigned agent.' });
  if (action === 'start') return res.json({ message: `Hi ${user.name.split(' ')[0]}. ${incident.id} is ${incident.slaPercentage}% through its SLA${incident.slaPercentage >= 100 ? ' and has breached its target' : ''}. Please acknowledge the alert so we can keep an audit trail.`, next: 'acknowledge', incident });
  if (action === 'acknowledge') {
    const result = await data.acknowledgeIncident(incidentId, user.id);
    if (result.error) return res.status(result.status).json({ error: result.error });
    return res.json({ message: 'Acknowledged. What is the primary reason this incident is at risk or breached?', next: 'reason', incident: result.incident });
  }
  if (action === 'reason') return res.json({ message: `You selected “${reason}”. Please add a short explanation of the current blocker and your next action.`, next: 'details', reason, incident });
  if (action === 'submit') {
    const result = await data.saveJustification(incidentId, user.id, { reason, details });
    if (result.error) return res.status(result.status).json({ error: result.error });
    return res.json({ message: 'Thank you. Your justification has been added to the incident work notes and is now available for management review.', next: 'complete', incident: result.incident });
  }
  res.status(400).json({ error: 'Unsupported Virtual Agent action.' });
}));

app.use(express.static(path.join(__dirname, '..', 'frontend')));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html')));

app.use((error, req, res, next) => {
  console.error(error);
  res.status(500).json({ error: error.message || 'The server could not complete this request.' });
});

if (require.main === module) {
  data.initializeDatabase()
    .then(() => app.listen(PORT, () => console.log(`SLA Breach Awareness app running on http://localhost:${PORT} with Supabase storage.`)))
    .catch((error) => {
      console.error(`Database startup failed: ${error.message}`);
      process.exitCode = 1;
    });
}

module.exports = app;
