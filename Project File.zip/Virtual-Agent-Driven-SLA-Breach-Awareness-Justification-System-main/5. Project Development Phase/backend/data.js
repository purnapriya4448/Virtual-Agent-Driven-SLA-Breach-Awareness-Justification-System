require('dotenv').config();

const { randomUUID } = require('crypto');
const { createClient } = require('@supabase/supabase-js');

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  throw new Error('Missing Supabase configuration. Add SUPABASE_URL and SUPABASE_SERVICE_KEY to .env.');
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false }
});

const now = () => new Date().toISOString();
const minutesAgo = (minutes) => new Date(Date.now() - minutes * 60_000).toISOString();
const minutesFromNow = (minutes) => new Date(Date.now() + minutes * 60_000).toISOString();

const DEFAULT_USERS = [
  { id: 'u-maya', name: 'Maya Patel', initials: 'MP', role: 'IT Agent', team: 'Infrastructure', canAdmin: false },
  { id: 'u-daniel', name: 'Daniel Kim', initials: 'DK', role: 'IT Agent', team: 'Service Desk', canAdmin: false },
  { id: 'u-priya', name: 'Priya Raman', initials: 'PR', role: 'IT Manager', team: 'Operations', canAdmin: false },
  { id: 'u-alex', name: 'Alex Morgan', initials: 'AM', role: 'ServiceNow Administrator', team: 'Platform', canAdmin: true }
];

function sampleIncidents() {
  return [
    {
      id: 'INC0010488', shortDescription: 'Customer portal is unavailable for external users', service: 'Customer Portal', priority: 'P1', status: 'In Progress', assignedTo: 'u-maya',
      openedAt: minutesAgo(202), slaDueAt: minutesFromNow(26), slaPercentage: 93, breachStatus: 'At risk', acknowledged: false, justification: null,
      workNotes: [{ id: 'wn-1', createdAt: minutesAgo(18), author: 'System', text: 'SLA alert sent to Maya Patel at 90% consumption.' }]
    },
    {
      id: 'INC0010481', shortDescription: 'VPN authentication failures after certificate rotation', service: 'Identity & Access', priority: 'P2', status: 'In Progress', assignedTo: 'u-daniel',
      openedAt: minutesAgo(390), slaDueAt: minutesFromNow(48), slaPercentage: 86, breachStatus: 'At risk', acknowledged: false, justification: null,
      workNotes: [{ id: 'wn-2', createdAt: minutesAgo(32), author: 'System', text: 'SLA alert sent to Daniel Kim at 80% consumption.' }]
    },
    {
      id: 'INC0010476', shortDescription: 'Finance reporting batch did not complete', service: 'Finance Reporting', priority: 'P2', status: 'In Progress', assignedTo: 'u-maya',
      openedAt: minutesAgo(642), slaDueAt: minutesAgo(21), slaPercentage: 104, breachStatus: 'Breached', acknowledged: true,
      justification: { reason: 'Third-party dependency', details: 'Vendor API was unavailable during the scheduled reconciliation window.', acknowledgedAt: minutesAgo(14), submittedBy: 'u-maya' },
      workNotes: [
        { id: 'wn-3', createdAt: minutesAgo(31), author: 'System', text: 'SLA breached. Justification requested from assigned agent.' },
        { id: 'wn-4', createdAt: minutesAgo(14), author: 'Maya Patel', text: 'SLA breach acknowledged. Reason: Third-party dependency. Vendor API was unavailable during the scheduled reconciliation window.' }
      ]
    },
    {
      id: 'INC0010469', shortDescription: 'New hire laptop software deployment delayed', service: 'End User Computing', priority: 'P3', status: 'In Progress', assignedTo: 'u-daniel',
      openedAt: minutesAgo(76), slaDueAt: minutesFromNow(274), slaPercentage: 42, breachStatus: 'On track', acknowledged: false, justification: null,
      workNotes: [{ id: 'wn-5', createdAt: minutesAgo(58), author: 'Daniel Kim', text: 'Awaiting user confirmation of preferred delivery time.' }]
    },
    {
      id: 'INC0010462', shortDescription: 'Warehouse label printer intermittently offline', service: 'Workplace Technology', priority: 'P3', status: 'In Progress', assignedTo: 'u-maya',
      openedAt: minutesAgo(310), slaDueAt: minutesFromNow(44), slaPercentage: 76, breachStatus: 'Watch', acknowledged: false, justification: null,
      workNotes: [{ id: 'wn-6', createdAt: minutesAgo(74), author: 'Maya Patel', text: 'Replacement network cable requested from onsite support.' }]
    },
    {
      id: 'INC0010454', shortDescription: 'Mobile device enrollment access request', service: 'Endpoint Management', priority: 'P3', status: 'Resolved', assignedTo: 'u-daniel',
      openedAt: minutesAgo(910), slaDueAt: minutesAgo(408), slaPercentage: 68, breachStatus: 'Met', acknowledged: false, justification: null,
      workNotes: [{ id: 'wn-7', createdAt: minutesAgo(420), author: 'Daniel Kim', text: 'Incident resolved and requester notified.' }]
    }
  ];
}

function dbUser(user) {
  return { id: user.id, name: user.name, initials: user.initials, role: user.role, team: user.team, can_admin: user.canAdmin };
}

function dbIncident(incident) {
  return {
    id: incident.id,
    short_description: incident.shortDescription,
    service: incident.service,
    priority: incident.priority,
    status: incident.status,
    assigned_to: incident.assignedTo,
    opened_at: incident.openedAt,
    sla_due_at: incident.slaDueAt,
    sla_percentage: incident.slaPercentage,
    breach_status: incident.breachStatus,
    acknowledged: incident.acknowledged,
    justification: incident.justification,
    work_notes: incident.workNotes
  };
}

function mapUser(row) {
  if (!row) return null;
  return { id: row.id, name: row.name, initials: row.initials, role: row.role, team: row.team, canAdmin: row.can_admin };
}

function mapIncident(row) {
  const assignedUser = mapUser(row.assigned_user);
  return {
    id: row.id,
    shortDescription: row.short_description,
    service: row.service,
    priority: row.priority,
    status: row.status,
    assignedTo: row.assigned_to,
    openedAt: row.opened_at,
    slaDueAt: row.sla_due_at,
    slaPercentage: Number(row.sla_percentage),
    breachStatus: row.breach_status,
    acknowledged: row.acknowledged,
    justification: row.justification,
    workNotes: row.work_notes || [],
    assignedUser,
    timeRemainingMinutes: Math.round((new Date(row.sla_due_at).getTime() - Date.now()) / 60_000)
  };
}

function readableError(error) {
  if (error?.code === '42P01' || /relation .* does not exist/i.test(error?.message || '')) {
    return new Error('Supabase tables are missing. Run supabase/schema.sql once in Supabase SQL Editor, then restart the app.');
  }
  return new Error(`Supabase request failed: ${error?.message || 'Unknown database error.'}`);
}

async function unwrap(request) {
  const { data, error, count } = await request;
  if (error) throw readableError(error);
  return { data, count };
}

function incidentSelect() {
  return '*, assigned_user:sla_users!sla_incidents_assigned_to_fkey(id,name,initials,role,team,can_admin)';
}

async function initializeDatabase() {
  const { data: currentUsers } = await unwrap(supabase.from('sla_users').select('id').limit(1));
  if (!currentUsers.length) await unwrap(supabase.from('sla_users').insert(DEFAULT_USERS.map(dbUser)));
  const { count } = await unwrap(supabase.from('sla_incidents').select('id', { count: 'exact', head: true }));
  if (!count) await unwrap(supabase.from('sla_incidents').insert(sampleIncidents().map(dbIncident)));
}

async function dbHealth() {
  await unwrap(supabase.from('sla_users').select('id', { head: true }).limit(1));
  return { storage: 'supabase-postgresql' };
}

async function listUsers() {
  const { data } = await unwrap(supabase.from('sla_users').select('*').order('name'));
  return data.map(mapUser);
}

async function getUser(userId) {
  if (!userId) return null;
  const { data } = await unwrap(supabase.from('sla_users').select('*').eq('id', userId).maybeSingle());
  return mapUser(data);
}

async function listIncidents(filters = {}) {
  let request = supabase.from('sla_incidents').select(incidentSelect()).order('sla_percentage', { ascending: false });
  if (filters.status && filters.status !== 'all') request = request.eq('breach_status', filters.status);
  if (filters.assignee && filters.assignee !== 'all') request = request.eq('assigned_to', filters.assignee);
  const { data } = await unwrap(request);
  let incidents = data.map(mapIncident);
  if (filters.search) {
    const needle = String(filters.search).toLowerCase();
    incidents = incidents.filter((incident) => `${incident.id} ${incident.shortDescription} ${incident.service}`.toLowerCase().includes(needle));
  }
  return incidents;
}

async function getIncident(id) {
  const { data } = await unwrap(supabase.from('sla_incidents').select(incidentSelect()).eq('id', id).maybeSingle());
  return data ? mapIncident(data) : null;
}

async function getNotifications(userId) {
  const incidents = await listIncidents({ assignee: userId });
  return incidents
    .filter((item) => item.status !== 'Resolved' && item.slaPercentage >= 80 && !item.justification)
    .map((item) => ({
      id: `alert-${item.id}`,
      incidentId: item.id,
      severity: item.slaPercentage >= 100 ? 'critical' : item.slaPercentage >= 90 ? 'high' : 'medium',
      title: item.slaPercentage >= 100 ? 'SLA breached — justification required' : `SLA at ${item.slaPercentage}% — action needed`,
      message: `${item.id}: ${item.shortDescription}`,
      createdAt: item.workNotes[item.workNotes.length - 1]?.createdAt || item.openedAt
    }));
}

async function getDashboard() {
  const [incidents, users] = await Promise.all([listIncidents(), listUsers()]);
  const active = incidents.filter((item) => item.status !== 'Resolved');
  const atRisk = active.filter((item) => item.slaPercentage >= 80 && item.slaPercentage < 100);
  const breached = active.filter((item) => item.slaPercentage >= 100);
  const justified = incidents.filter((item) => item.justification);
  const needsJustification = breached.filter((item) => !item.justification);
  const byAssignee = users.filter((user) => user.role === 'IT Agent').map((user) => {
    const assigned = active.filter((item) => item.assignedTo === user.id);
    const breachedAssigned = assigned.filter((item) => item.slaPercentage >= 100).length;
    return { user, active: assigned.length, atRisk: assigned.filter((item) => item.slaPercentage >= 80).length, compliance: assigned.length ? Math.round(((assigned.length - breachedAssigned) / assigned.length) * 100) : 100 };
  });
  return {
    totals: { active: active.length, atRisk: atRisk.length, breached: breached.length, justified: justified.length, needsJustification: needsJustification.length },
    performance: { onTrack: active.filter((item) => item.slaPercentage < 80).length, watch: active.filter((item) => item.slaPercentage >= 80 && item.slaPercentage < 90).length, critical: active.filter((item) => item.slaPercentage >= 90 && item.slaPercentage < 100).length, breached: breached.length },
    byAssignee,
    recentActivity: incidents.flatMap((incident) => incident.workNotes.map((note) => ({ ...note, incidentId: incident.id, incidentTitle: incident.shortDescription }))).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 8)
  };
}

async function saveJustification(id, userId, { reason, details }) {
  const incident = await getIncident(id);
  if (!incident) return { error: 'Incident not found.', status: 404 };
  if (incident.assignedTo !== userId) return { error: 'Only the assigned agent can submit this SLA justification.', status: 403 };
  if (!reason || !details || details.trim().length < 10) return { error: 'Please choose a reason and provide at least 10 characters of detail.', status: 400 };
  const user = await getUser(userId);
  const justification = { reason: reason.trim(), details: details.trim(), acknowledgedAt: now(), submittedBy: userId };
  const note = { id: randomUUID(), createdAt: now(), author: user.name, text: `SLA breach acknowledged. Reason: ${reason.trim()}. ${details.trim()}` };
  await unwrap(supabase.from('sla_incidents').update({ acknowledged: true, justification, work_notes: [...incident.workNotes, note], updated_at: now() }).eq('id', id));
  return { incident: await getIncident(id) };
}

async function acknowledgeIncident(id, userId) {
  const incident = await getIncident(id);
  if (!incident) return { error: 'Incident not found.', status: 404 };
  if (incident.assignedTo !== userId) return { error: 'Only the assigned agent can acknowledge this SLA alert.', status: 403 };
  const user = await getUser(userId);
  const note = { id: randomUUID(), createdAt: now(), author: user.name, text: 'SLA risk acknowledged through Virtual Agent. Justification pending.' };
  await unwrap(supabase.from('sla_incidents').update({ acknowledged: true, work_notes: [...incident.workNotes, note], updated_at: now() }).eq('id', id));
  return { incident: await getIncident(id) };
}

async function createIncident({ shortDescription, service, priority, assignedTo, slaPercentage, minutesToBreach }) {
  const { data: lastRows } = await unwrap(supabase.from('sla_incidents').select('id').order('id', { ascending: false }).limit(1));
  const lastNumber = Number.parseInt(lastRows[0]?.id?.replace('INC', ''), 10) || 10488;
  const id = `INC${String(lastNumber + 1).padStart(7, '0')}`;
  const percentage = Number(slaPercentage);
  const minutes = Number(minutesToBreach);
  const breachStatus = percentage >= 100 ? 'Breached' : percentage >= 80 ? 'At risk' : percentage >= 70 ? 'Watch' : 'On track';
  const incident = {
    id, shortDescription: shortDescription.trim(), service: service.trim(), priority, status: 'In Progress', assignedTo,
    openedAt: now(), slaDueAt: minutesFromNow(minutes), slaPercentage: percentage, breachStatus, acknowledged: false, justification: null,
    workNotes: [{ id: randomUUID(), createdAt: now(), author: 'System', text: 'Incident created in the Supabase SLA monitoring workspace.' }]
  };
  if (percentage >= 80) incident.workNotes.push({ id: randomUUID(), createdAt: now(), author: 'System', text: `SLA monitoring alert generated at ${percentage}% consumption.` });
  await unwrap(supabase.from('sla_incidents').insert(dbIncident(incident)));
  return getIncident(id);
}

async function getReport() {
  const incidents = await listIncidents();
  return incidents.filter((item) => item.status !== 'Resolved' || item.slaPercentage >= 100).map((item) => ({
    id: item.id, service: item.service, priority: item.priority, assignedTo: item.assignedUser.name, slaPercentage: item.slaPercentage,
    breachStatus: item.breachStatus, justificationStatus: item.justification ? 'Submitted' : item.slaPercentage >= 100 ? 'Required' : 'Not required',
    justificationReason: item.justification?.reason || '—', updatedAt: item.workNotes[item.workNotes.length - 1]?.createdAt
  }));
}

module.exports = { DEFAULT_USERS, initializeDatabase, dbHealth, listUsers, getUser, listIncidents, getIncident, getNotifications, getDashboard, saveJustification, acknowledgeIncident, createIncident, getReport };
