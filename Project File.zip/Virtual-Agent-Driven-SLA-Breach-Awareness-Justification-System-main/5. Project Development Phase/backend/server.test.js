const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const app = require('./server');
const data = require('./data');

let server;
let baseUrl;

test.before(async () => {
  await data.initializeDatabase();
  server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

test.after(() => new Promise((resolve) => server.close(resolve)));

test('health endpoint reports Supabase PostgreSQL storage', async () => {
  const response = await fetch(`${baseUrl}/api/health`);
  assert.equal(response.status, 200);
  assert.equal((await response.json()).storage, 'supabase-postgresql');
});

test('production server serves the SLA workspace frontend', async () => {
  const response = await fetch(`${baseUrl}/`);
  assert.equal(response.status, 200);
  const html = await response.text();
  assert.match(html, /Virtual Agent/);
  assert.match(html, /app\.js/);
});

test('only an incident assignee can submit an SLA justification', async () => {
  const response = await fetch(`${baseUrl}/api/incidents/INC0010488/justification`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-demo-user-id': 'u-daniel' },
    body: JSON.stringify({ reason: 'Third-party dependency', details: 'A sufficiently detailed explanation.' })
  });
  assert.equal(response.status, 403);
});

test('dashboard is populated from the Supabase seed data', async () => {
  const response = await fetch(`${baseUrl}/api/dashboard`);
  assert.equal(response.status, 200);
  assert.ok((await response.json()).totals.active >= 1);
});
