-- Virtual Agent–Driven SLA Breach Awareness & Justification System
-- Run this file once in Supabase Dashboard → SQL Editor → New query.
-- The Node backend seeds sample users and incidents on its first successful start.

begin;

create table if not exists public.sla_users (
  id text primary key,
  name text not null,
  initials text not null,
  role text not null,
  team text not null,
  can_admin boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.sla_incidents (
  id text primary key,
  short_description text not null,
  service text not null,
  priority text not null check (priority in ('P1', 'P2', 'P3')),
  status text not null default 'In Progress',
  assigned_to text not null references public.sla_users(id) on update cascade,
  opened_at timestamptz not null,
  sla_due_at timestamptz not null,
  sla_percentage numeric(6,2) not null check (sla_percentage >= 0 and sla_percentage <= 200),
  breach_status text not null,
  acknowledged boolean not null default false,
  justification jsonb,
  work_notes jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists sla_incidents_assigned_to_idx on public.sla_incidents(assigned_to);
create index if not exists sla_incidents_sla_percentage_idx on public.sla_incidents(sla_percentage desc);

-- The browser never connects to these tables. The backend uses a server-only secret key.
alter table public.sla_users enable row level security;
alter table public.sla_incidents enable row level security;

revoke all on table public.sla_users from anon, authenticated;
revoke all on table public.sla_incidents from anon, authenticated;
grant select, insert, update, delete on table public.sla_users to service_role;
grant select, insert, update, delete on table public.sla_incidents to service_role;

commit;
