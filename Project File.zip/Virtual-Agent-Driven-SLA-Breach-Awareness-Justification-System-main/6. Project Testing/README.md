
# Phase 6 – Project Testing
## Virtual Agent–Driven SLA Breach Awareness & Justification System

This document describes the functional test cases executed to validate the **Virtual Agent–Driven SLA Breach Awareness & Justification System**.

---

# Test Case 1 – Incident Creation

**Objective**

To verify that an Incident can be created and an SLA is applied.

**Steps**

1. Navigate to **Incident → Create New**
2. Fill in all mandatory fields.
3. Submit the incident.

**Expected Result**

- Incident is created successfully.
- Incident Number is generated.
- SLA is attached to the Incident automatically.

---

# Test Case 2 – SLA Attachment & Running

**Objective**

To verify that the SLA is attached and starts running.

**Steps**

1. Open the created Incident.
2. Navigate to **Related Lists → Task SLA**.

**Expected Result**

- SLA record is visible.
- SLA Due field is populated.
- SLA percentage starts increasing.

---

# Test Case 3 – SLA At Risk Trigger

**Objective**

To verify that the SLA At Risk flag updates automatically.

**Steps**

1. Wait until SLA crosses the configured threshold (≥80%).
2. Refresh the Incident.

**Expected Result**

- **SLA At Risk = True** automatically after crossing 80%.

---

# Test Case 4 – SLA Notification Email (Assigned To)

**Objective**

To notify the assigned user when the SLA is at risk.

**Steps**

1. Check the inbox or Notification Preview.
2. Open the SLA warning email.

**Expected Result**

- Email is received.
- SLA warning message is displayed.
- Service Portal/Dashboard link is available.

**Evidence**

- Screenshot 1: Email received by **Assigned To**.

---

# Test Case 5 – SLA Notification Email (Manager)

**Objective**

To notify the assignee's manager when the SLA is at risk.

**Steps**

1. Check manager inbox.
2. Open SLA notification email.

**Expected Result**

- Manager receives SLA warning email.
- Incident details are included.
- Service Portal/Dashboard link is available.

**Evidence**

- Screenshot 2: Email received by **Assigned To's Manager**.

---

# Test Case 6 – Virtual Agent Invocation

**Objective**

To guide users through conversational SLA governance.

**Steps**

1. Open the Service Portal.
2. Launch Virtual Agent.
3. Select **SLA Breach Awareness & Justification**.

**Expected Result**

- SLA warning message is displayed.
- Governance instructions are shown.

---

# Test Case 7 – SLA Acknowledgement via Virtual Agent

**Objective**

To capture user acknowledgement.

**Steps**

1. Click **Yes** in the Virtual Agent.

**Expected Result**

- Confirmation message is displayed.
- Acknowledgement is stored successfully.

---

# Test Case 8 – Reporting: SLA Breaches by Reason

**Objective**

To visualize SLA breach distribution.

**Expected Result**

- Pie chart grouped by **SLA Breach Reason** is displayed.

---

# Test Case 9 – Reporting: Acknowledged vs Unacknowledged

**Objective**

To track SLA accountability.

**Expected Result**

- Dashboard displays acknowledged versus unacknowledged SLA breaches.

---

# Test Case 10 – Reporting: Pending Justifications

**Objective**

To identify incidents with missing justifications.

**Expected Result**

- List displays incidents where **SLA At Risk = True**.
- Missing justification records are highlighted.

---

# Test Case 11 – Dashboard: SLA Governance View

**Objective**

To provide centralized SLA visibility.

**Steps**

1. Open **SLA Governance & Accountability Dashboard**.

**Expected Result**

- All dashboard widgets load successfully.
- SLA metrics, breach trends, acknowledgements, and pending justifications are displayed correctly.

---

## Test Summary

| Total Test Cases | Passed | Failed | Status |
|-----------------:|------:|------:|--------|
| 11 | 11 | 0 | Successful |

**Conclusion**

All functional test cases were executed successfully. The solution correctly monitored SLA progress, generated notifications, invoked the Virtual Agent, captured acknowledgements, updated incident records, and displayed governance reports and dashboards as expected.
