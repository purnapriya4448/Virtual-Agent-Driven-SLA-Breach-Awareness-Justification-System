# Phase 4: Project Planning Phase
This document outlines the development timeline, sprint schedules, and milestone targets for the SLA Breach Awareness & Justification System.

---

## 1. Project Milestones

| Milestone | Target Deliverable | Completion Status |
| :--- | :--- | :--- |
| **Milestone 1** | **Backend Foundation**: SQLite seed mapping, localStorage schema structures, and priority limits inside `data.js`. | Completed |
| **Milestone 2** | **Frontend Layout**: Responsive sidebar tabs, top role selectors, user badges, and bottom simulation bars in `index.html`. | Completed |
| **Milestone 3** | **Styling System**: CSS variable systems, glassmorphism layouts, custom scrollbars, and neon priority badges in `styles.css`. | Completed |
| **Milestone 4** | **SLA Ticking Engine**: Simulated clocks, time acceleration controllers, percentage calculations ($80\%$ warning / $100\%$ breach), and audit logs in `app.js`. | Completed |
| **Milestone 5** | **Virtual Agent Chat**: Dialogue trees, choice button arrays, input validations, and SLA pause states in `app.js`. | Completed |
| **Milestone 6** | **Governance & Reports**: Governance logs, manager approval action buttons, CSV exporters, and dynamic Chart.js feeds in `app.js`. | Completed |
| **Milestone 7** | **Testing & Launch**: Walkthrough validation guidelines and project completion checklist in `walkthrough.md`. | Completed |

---

## 2. Work Breakdown Structure (WBS)

### Sprint 1: Database Schema & Initial Data Seeding
* Define priority limits, response/resolution target limits, and configuration defaults inside `data.js`.
* Extend simulated Incident schemas to include `u_requires_justification`, `u_justification_reason`, `u_justification_comment`, `u_justification_status`, and `u_manager_comments`.
* Establish session management functions inside `data.js` utilizing `localStorage` to save ticket histories and configurations.

### Sprint 2: Frontend Shell & Glassmorphic Design System
* Scaffold the main HTML structures in `index.html` featuring sidebar tabs, metric headers, tables, and modal skeletons.
* Define custom CSS variables, custom scrollbars, animations, and glassmorphism cards in `styles.css`.
* Build responsive headers, user avatars, and the interactive Role Selector dropdown in the top utility bar.

### Sprint 3: SLA Engine Ticking & Time Acceleration Controls
* Program simulated clock ticks in `app.js` to increment elapsed times on active, unresolved tickets.
* Implement time acceleration controls (+1 Min, +5 Mins, +1 Hour, Auto-tick) to facilitate testing.
* Write calculations to update ticket states (Compliant $\to$ Warning $\to$ Breached) and trigger top warning alerts at $80\%$ elapsed SLA targets.

### Sprint 4: Virtual Agent & Conversational Justification Loops
* Program the Virtual Agent chatbot dialog tree inside `app.js` (Greeting $\to$ Reason Buttons $\to$ Detail Comments).
* Enable inputs dynamically so resolvers can submit breach justifications that write directly to the target record's database fields.
* Establish post-justification shortcuts like ticket status updates (e.g. moving a ticket to "On Hold" to suspend SLA timers).

### Sprint 5: Manager Governance & Audit Review Board
* Create the Governance Log table displaying justification logs pending review.
* Program approval, rejection, and comment interfaces that show/hide based on the active role selector.
* Write Client-side CSV file compilation and download exporter logic.

### Sprint 6: Executive Analytics, Testing & Deployments
* Integrate Chart.js widgets to track real-time compliance trends and reason distributions.
* Define testing checklists in `walkthrough.md` to verify clock controls, UI policies, and role access constraints.
* Finalize code structure and deploy to workspace path.
