# Phase 2: Requirement Analysis & Planning: SLA Breach Awareness & Justification System

This document provides a detailed breakdown of the requirements, scope, stakeholders, and data flow analyzed during the planning phase of the Virtual Agent–Driven SLA Breach Awareness & Justification System.

---

## 1. Executive Summary & Business Objectives

Organizations face significant customer satisfaction and financial penalties due to missed Service Level Agreements (SLAs). The goal of this system is to transition from **reactive firefighting** to **proactive governance** by leveraging automated triggers, conversational user interfaces, and structured justification loops.

```mermaid
graph LR
    A[Proactive Awareness] --> B[SLA Breach Reduction]
    B --> C[Stronger Accountability]
    C --> D[Audit Readiness]
    D --> E[Operational Transparency]
    style A fill:#4f46e5,stroke:#fff,stroke-width:1px,color:#fff
    style E fill:#10b981,stroke:#fff,stroke-width:1px,color:#fff
```

### Key Business Metrics (KPIs) Targeted:
1. **SLA Compliance Rate**: Target $\ge 95\%$ compliance across all priority tiers.
2. **Average Time-to-Justify**: Reduce the delay in documenting breaches to $< 15$ minutes post-warning.
3. **Audit Completeness**: $100\%$ of breached SLAs must have a validated, manager-approved justification.
4. **Agent Friction**: Minimize time spent writing justification details through conversational forms.

---

## 2. MoSCoW Prioritization Matrix

To align engineering effort with business value, the requirements are prioritized as follows:

| Category | Requirement Description | Native ServiceNow Component |
| :--- | :--- | :--- |
| **MUST HAVE** | **SLA Monitoring & Triggers**: Real-time tracking of SLA progress, triggering alerts at $80\%$ warning and $100\%$ breach. | SLA Definitions (`contract_sla`) & Task SLA (`task_sla`) |
| | **Virtual Agent Justification Flow**: Conversational prompt to capture predefined reason categories and resolver comments. | Virtual Agent Designer |
| | **Security / RBAC Access Control**: Only the assigned resolver can submit/modify a justification; read-only for others. | Access Control Lists (ACLs) & Data Policies |
| | **Automatic Incident Updates**: Log justifications in Incident Work Notes and save structured records to incident fields. | Incident Table (`incident`) / Flow Designer |
| **SHOULD HAVE** | **Manager Approval Loop**: Interface for managers to approve, reject, or request clarification on breach justifications. | Flow Designer Approval Tasks |
| | **Executive Dashboard**: Dynamic reporting charts displaying breach reasons, SLA trends, and acknowledgment rates. | ServiceNow Dashboards & Analytics |
| | **Compliance Log Exporter**: Ability to export justification audit histories to CSV/PDF for compliance reviews. | ServiceNow Reports Engine |
| **COULD HAVE** | **Multi-Channel Alerts**: Pushing warning notifications to Slack, MS Teams, and Email with deep links to VA. | Flow Designer IntegrationHub |
| | **On-Hold Suspension**: Ability to pause the SLA timer directly from the chat menu by changing incident state to "On Hold". | SLA Engine Transitions |
| **WON'T HAVE** | **AI-Generated Auto-Resolutions**: Automatically resolving incidents using machine learning. | Out of scope for Phase 1 |

---

## 3. Detailed Functional Requirements

### FR-1: SLA Monitoring & State Engine
* **FR-1.1**: The system must track both Response SLAs and Resolution SLAs on all Incident records.
* **FR-1.2**: The system must continuously calculate the SLA elapsed time percentage:
  $$\text{SLA Progress \%} = \left( \frac{\text{Elapsed Time}}{\text{SLA Target Duration}} \right) \times 100$$
* **FR-1.3**: The SLA status must transition automatically based on thresholds:
  * **Compliant**: $< 80\%$ elapsed.
  * **Warning**: $\ge 80\%$ and $< 100\%$ elapsed.
  * **Breached**: $\ge 100\%$ elapsed.

### FR-2: Virtual Agent (VA) Dialog Flow
* **FR-2.1**: When a ticket transitions to the **Warning** state, the system must trigger a proactive VA notification to the assigned resolver.
* **FR-2.2**: The VA dialogue must present a multi-choice input of delay categories:
  * *Awaiting Customer Response*
  * *Third-Party Vendor Delay*
  * *High Technical Complexity / Research Required*
  * *Resource / Staff Shortage*
  * *Hardware Procurement / Provisioning Delay*
* **FR-2.3**: The VA must mandate a text description explaining the delay details.
* **FR-2.4**: The VA must allow the agent to change the ticket state to 'On Hold' (suspending the SLA) directly from the chat interface.

### FR-3: Incident Automation & Audit Logging
* **FR-3.1**: Once a justification is submitted, the system must write the detail fields (`u_justification_reason`, `u_justification_comment`, `u_submitted_by`, `u_submitted_at`) to the Incident record.
* **FR-3.2**: A system work note must be posted automatically in the incident activity stream: 
  * *Format: "Breach Justification submitted via Virtual Agent. Reason: [Reason]. Comments: [Comments]"*
* **FR-3.3**: The ticket's justification fields must be locked (read-only) for resolvers once submitted, allowing edits only by users with the `manager` or `sla_governor` role.

---

## 4. User Stories

### User Story 1: Support Agent SLA Warning Alert
> **As an** IT Support Agent (Resolver),  
> **I want** the Virtual Agent to proactively alert me when a ticket is approaching $80\%$ of its SLA,  
> **So that** I can take immediate corrective actions or document the reason for delay before a breach occurs.

### User Story 2: Mandatory Justification Control
> **As an** IT Desk Manager,  
> **I want** the system to enforce mandatory justification inputs on warning/breached tickets,  
> **So that** we do not have unannotated SLA violations in our audit history.

### User Story 3: Governance & Review Panel
> **As an** IT Service Desk Manager (Governor),  
> **I want** a dedicated list of pending SLA breach justifications to review, approve, or reject,  
> **So that** I can maintain accountability and ensure justifications are valid.

---

## 5. Security & Access Control Matrix (RBAC)

To protect the integrity of the audit logs, role-based controls are defined as follows:

| Role Name | Table / Field | Read Access | Write Access | Create Access | Delete Access |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **itil_resolver** | Incident Details | Yes | Yes (If assigned) | Yes | No |
| | Justification Fields | Yes | Yes (Only during active VA flow) | Yes (One-time) | No |
| **manager** | Incident Details | Yes | Yes | Yes | No |
| | Justification Fields | Yes | Yes (Manager Comments) | Yes | No |
| | Governance Log Panel | Yes | Yes (Approve/Reject actions) | Yes | No |
| **sla_administrator**| System SLA Configs | Yes | Yes | Yes | Yes |
| | Justification Categories | Yes | Yes | Yes | Yes |
